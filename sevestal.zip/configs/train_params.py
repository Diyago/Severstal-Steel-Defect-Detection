sample_submission_path = './input/severstal-steel-defect-detection/sample_submission.csv'
train_df_path = './input/severstal-steel-defect-detection/train.csv'
data_folder = "./input/severstal-steel-defect-detection/"
test_data_folder = "./input/severstal-steel-defect-detection/test_images"

isDebug = True
unet_encoder = 'se_resnext50_32x4d'
ATTENTION_TYPE = None  # None # Only for UNET scse
num_epochs = 45
LEARNING_RATE = 5e-4
BATCH_SIZE = {"train": 4, "val": 2}
TOTAL_FOLDS = 10
model_weights = 'imagenet'
EARLY_STOPING = 15


crop_image_size = None #(256, 416)
INITIAL_MINIMUM_DICE = 0.89

if isDebug:
    num_epochs = 1
